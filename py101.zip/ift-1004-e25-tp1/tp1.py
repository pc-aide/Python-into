from random import uniform

ESSENCE_PRIX_MIN = 102
ESSENCE_PRIX_MAX = 150

prix_essence_du_jour = round(uniform(ESSENCE_PRIX_MIN, ESSENCE_PRIX_MAX), 1)

print(prix_essence_du_jour)
